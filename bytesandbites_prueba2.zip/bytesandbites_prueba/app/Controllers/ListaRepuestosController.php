<?php

namespace App\Controllers;

use App\Models\ListaRepuestosModel;

class ListaRepuestosController extends BaseController
{
    public function index(): string
    {
        $repuesto = new ListaRepuestosModel();
        $datos['datos'] = ($repuesto->findAll());

        return view('lista_repuestos', $datos);
    }

    public function nuevoRepuesto(): string
    {   
        return view('nuevo_repuesto');
    }

    public function agregarRepuesto()
    {
        $datos=[
            'id_repuesto' => $this->request->getVar('txt_id_repuesto'),
            'nombre' => $this->request->getVar('txt_nombre'),
            'id_tipo_equipo' => $this->request->getVar('txt_tipo_equipo'),
            'id_marca' => $this->request->getVar('txt_marca'),
            'modelo' => $this->request->getVar('txt_modelo'),
            'precio' => $this->request->getVar('txt_precio'),
            'img_repuesto' => $this->request->getVar('txt_imagen'),
            'img_repuesto' => $this->request->getVar('txt_cantidad'),
            'id_proveedor' => $this->request->getVar('txt_proveedor'),
            'descripcion' => $this->request->getVar('txt_descripcion_repuesto')
        ];

        //print_r($datos);
        $repuesto = new ListaRepuestosModel();
        $repuesto->insert($datos);
        return redirect()->route('lista_repuestos');


    }

    
    public function buscarCliente($id=null)
    {
        $repuesto = new ListaRepuestosModel();
        $datos['datos']=$repuesto->where('cliente_id',$id)->first();
        return view('cliente_modificar', $datos);
        //print_r($datos);
    }
    
    public function modificarCliente()
    {
        $datos=[
            'cliente_id' => $this->request->getVar('txtId'),
            'apellido' => $this->request->getVar('txtApellido'),
            'nombre' => $this->request->getVar('txtNombre'),
            'nit' => $this->request->getVar('txtNit'),
            'telefono' => $this->request->getVar('txtTel'),
            'correo_electronico' => $this->request->getVar('txtEmail'),
            'direccion' => $this->request->getVar('txtDireccion'),
            'contrasenia' => $this->request->getVar('txtPassword')
        ];
        
        //print_r($datos);
        $repuesto = new ListaRepuestosModel();
        $repuesto -> update($datos['cliente_id'],$datos);
        return redirect()->route('lista_repuestos');
    }

    public function eliminarCliente($id=null)
    {
        //echo $id;
        $repuesto = new ListaRepuestosModel();
        $repuesto->delete(['cliente_id'=>$id]);
        return redirect()->route('lista_repuestos');
    }
    
}