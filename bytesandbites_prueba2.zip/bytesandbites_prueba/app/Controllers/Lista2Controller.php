<?php

namespace App\Controllers;

use App\Models\Lista2Model;

class Lista2Controller extends BaseController
{
    public function index()
    {
        $repuestoModel = new Lista2Model();
        $repuestos = $repuestoModel->getRepuestos();

        // Cargar la vista y pasar los datos
        return view('lista2', ['repuestos' => $repuestos]);
    }
}