<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

/*Agente de Servicio*/
$routes->get('ordenes_servicio', 'OrdenesServicioController::index');
$routes->get('nueva_orden_servicio', 'NuevaOrdenController::nuevaOrden');
$routes->post('agregar_orden', 'NuevaOrdenController::agregarOrden');

/*Encargado de Bodega*/
$routes->get('lista2', 'Lista2Controller::index');
$routes->get('lista_repuestos', 'ListaRepuestosController::index');
$routes->get('nuevo_repuesto', 'NuevoRepuestoController::nuevoRepuesto');
$routes->post('actualizar_repuestos', 'ActuaRepuestosController::agregarRepuesto');
