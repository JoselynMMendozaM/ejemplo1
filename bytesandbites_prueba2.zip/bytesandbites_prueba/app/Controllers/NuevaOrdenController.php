<?php

namespace App\Controllers;

use App\Models\NuevaOrdenModel;

class NuevaOrden extends BaseController
{
    public function index(): string
    {
        $ciudadano = new NuevaOrdenModel();
        $datos['datos']=($ciudadano->findAll()); 

        return view('ordenes_servicio', $datos); // Pass data to the view
    }

    public function nuevaOrden(): string
    {
        return view('nueva_orden_servicio');
    }

    public function agregarOrden()
        {
            $datos=[
                'dpi' => $this->request->getVar('txtDpi'),
                'primer_nombre' => $this->request->getVar('txtApellido'),
                'segudo_nombre' => $this->request->getVar('txtApellido'),
                'primer_apellido' => $this->request->getVar('txtApellido'),
                'segudo_apellido' => $this->request->getVar('txtApellido'),
                'nit' => $this->request->getVar('txtNombre'),
                'email' => $this->request->getVar('txtDireccion'),
                'telefono' => $this->request->getVar('txtTelCasa'),
                'id_empresa' => $this->request->getVar('txtTelMovil'),
                'id_tipo_equipo' => $this->request->getVar('txtIdNivelAcad'),
                'id_marca' => $this->request->getVar('txtIdMuni'),
                'modelo' => $this->request->getVar('txtContra'),
                'descripcion_cliente' => $this->request->getVar('txtContra'),
                'id_agente' => $this->request->getVar('txtContra'),
                'evaluacion_agente' => $this->request->getVar('txtContra'),
                'observaciones' => $this->request->getVar('txtContra'),
                'espesificaciones_equipo' => $this->request->getVar('txtContra'),
                'fecha_recepcion' => $this->request->getVar('txtEmail'),
                'fecha_entrega_estimada' => $this->request->getVar('txtFechaNac')
                
            ];



           
            //crear un objeto de tipo clienteModel
            $ciudadano = new CiudadanosModel();
            $ciudadano->insert($datos);
            return redirect()->route('ordenes_servicio');
        }

    public function buscarCiudadano($id=null)
    {
        $ciudadano = new CiudadanosModel();
        $datos['datos']=$ciudadano->where('dpi',$id)->first();
        return view('ciudadano_modificar', $datos);
        //print_r($datos);
    }
    
    public function modificarCiudadano()
    {
        $datos=[
            'dpi' => $this->request->getVar('txtDpi'),
            'apellido' => $this->request->getVar('txtApellido'),
            'nombre' => $this->request->getVar('txtNombre'),
            'direccion' => $this->request->getVar('txtDireccion'),
            'tel_casa' => $this->request->getVar('txtTelCasa'),
            'tel_movil' => $this->request->getVar('txtTelMovil'),
            'email' => $this->request->getVar('txtEmail'),
            'fechanac' => $this->request->getVar('txtFechaNac'),
            'cod_nivel_acad' => $this->request->getVar('txtIdNivelAcad'),
            'cod_muni' => $this->request->getVar('txtIdMuni'),
            'contra' => $this->request->getVar('txtContra')
            
        ];

        //print_r($datos);
        $ciudadano = new CiudadanosModel();
        $ciudadano -> update($datos['id_cliente'],$datos);
        return redirect()->route('ordenes_servicio');
    }
        
    
    public function eliminarCiudadano($id=null)
    {
        //echo $id;
        $ciudadano = new CiudadanosModel();
        $ciudadano->delete(['id_cliente'=>$id]);
        return redirect()->route('ordenes_servicio');
    }

}