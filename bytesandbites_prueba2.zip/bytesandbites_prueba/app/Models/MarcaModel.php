<?php

    namespace App\Models;

    use CodeIgniter\Model;

    class MarcaModel extends Model
{
    protected $table      = 'marcas';
    protected $primaryKey = 'id_marca';

    protected $allowedFields = [
        'id_marca'
        ,'nombre_marca'
    ];

	

}
